from django.contrib import admin
from .models import Beverage,Coffee
# Register your models here.
admin.site.register(Beverage)
admin.site.register(Coffee)